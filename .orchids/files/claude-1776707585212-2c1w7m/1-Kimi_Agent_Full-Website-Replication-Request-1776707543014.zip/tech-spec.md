# Reform Skincare — Technical Specification

## 1. Component Inventory

### shadcn/ui Components (Built-in)

| Component | Usage | Installation |
|-----------|-------|--------------|
| Button | CTAs, navigation buttons | `npx shadcn add button` |
| Accordion | Services section expand/collapse | `npx shadcn add accordion` |
| Input | Contact forms, booking forms | `npx shadcn add input` |
| Textarea | Message field in contact form | `npx shadcn add textarea` |
| Select | "I am interested in" dropdown | `npx shadcn add select` |
| Card | Testimonial cards, feature cards | `npx shadcn add card` |
| Tabs | Team member section | `npx shadcn add tabs` |
| Sheet | Mobile menu drawer | `npx shadcn add sheet` |
| Separator | Dividers between sections | `npx shadcn add separator` |

### Custom Components

| Component | Purpose | Location |
|-----------|---------|----------|
| TopHeader | Black header bar with logo, menu, CTAs | `src/sections/TopHeader.tsx` |
| Navbar | Navigation links bar | `src/sections/Navbar.tsx` |
| HeroSection | Video background hero with CTAs | `src/sections/HeroSection.tsx` |
| BrandsSection | Trusted brands marquee | `src/sections/BrandsSection.tsx` |
| WhatWeDo | Clinic description + feature cards | `src/sections/WhatWeDo.tsx` |
| ServicesSection | Accordion services grid | `src/sections/ServicesSection.tsx` |
| TeamSection | Tabbed team member display | `src/sections/TeamSection.tsx` |
| CTASection | Dark booking CTA with form | `src/sections/CTASection.tsx` |
| GallerySection | Image carousel | `src/sections/GallerySection.tsx` |
| ProcessSection | 3-step process timeline | `src/sections/ProcessSection.tsx` |
| TestimonialsSection | Review cards carousel | `src/sections/TestimonialsSection.tsx` |
| ContactSection | Map + contact form | `src/sections/ContactSection.tsx` |
| FooterSection | Footer with links and info | `src/sections/FooterSection.tsx` |
| SectionBadge | Reusable pill badge with dot | `src/components/SectionBadge.tsx` |
| StarRating | 5-star rating display | `src/components/StarRating.tsx` |
| ImageCarousel | Reusable carousel with arrows | `src/components/ImageCarousel.tsx` |
| AnimatedSection | Scroll-triggered fade-in wrapper | `src/components/AnimatedSection.tsx` |

## 2. Animation Implementation Table

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Page load fade-in | Framer Motion | AnimatePresence on mount | Low |
| Section scroll reveal | Framer Motion | whileInView with y offset | Medium |
| Staggered children | Framer Motion | staggerChildren in variants | Medium |
| Hero text entrance | Framer Motion | Sequential fade-up with delays | Medium |
| Button hover scale | Tailwind + Framer | whileHover={{ scale: 1.02 }} | Low |
| Accordion expand | Framer Motion | AnimatePresence + height auto | Medium |
| Icon rotation | Tailwind | rotate-45 transition on toggle | Low |
| Gallery carousel | Framer Motion | drag + animate x position | Medium |
| Testimonial carousel | Framer Motion | AnimatePresence crossfade | Medium |
| Tab content switch | Framer Motion | AnimatePresence mode="wait" | Medium |
| Card hover lift | Tailwind | hover:-translate-y-1 transition | Low |
| Process step reveal | Framer Motion | whileInView stagger | Medium |
| Nav underline | CSS | after pseudo-element scaleX | Low |
| Mobile menu | Framer Motion | Sheet slide + fade | Medium |

## 3. Animation Library Choices

### Primary: Framer Motion
- React-native integration
- Declarative API
- Built-in gesture support
- AnimatePresence for enter/exit
- whileInView for scroll triggers

### Secondary: Tailwind CSS Transitions
- Simple hover states
- Color transitions
- Transform transitions

## 4. Project File Structure

```
/mnt/agents/output/app/
├── public/
│   ├── images/
│   │   ├── hero-bg.jpg
│   │   ├── service-anti-wrinkle.jpg
│   │   ├── team-priya.jpg
│   │   ├── gallery-1.jpg
│   │   ├── gallery-2.jpg
│   │   ├── gallery-3.jpg
│   │   └── cta-bg.jpg
│   └── videos/
│       └── hero-bg.mp4
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn components
│   │   ├── SectionBadge.tsx
│   │   ├── StarRating.tsx
│   │   ├── ImageCarousel.tsx
│   │   └── AnimatedSection.tsx
│   ├── sections/
│   │   ├── TopHeader.tsx
│   │   ├── Navbar.tsx
│   │   ├── HeroSection.tsx
│   │   ├── BrandsSection.tsx
│   │   ├── WhatWeDo.tsx
│   │   ├── ServicesSection.tsx
│   │   ├── TeamSection.tsx
│   │   ├── CTASection.tsx
│   │   ├── GallerySection.tsx
│   │   ├── ProcessSection.tsx
│   │   ├── TestimonialsSection.tsx
│   │   ├── ContactSection.tsx
│   │   └── FooterSection.tsx
│   ├── hooks/
│   │   └── useScrollAnimation.ts
│   ├── lib/
│   │   └── utils.ts
│   ├── App.tsx
│   ├── App.css
│   ├── index.css
│   └── main.tsx
├── index.html
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

## 5. Dependencies to Install

```bash
# Animation library
npm install framer-motion

# Icons
npm install lucide-react

# Google Fonts (loaded via index.html)
# Playfair Display + Inter
```

## 6. Tailwind Configuration

```javascript
// tailwind.config.js extensions
{
  theme: {
    extend: {
      colors: {
        cream: '#EDE8E2',
        'brand-black': '#000000',
        'brand-gray': '#6B6B6B',
        'star-gold': '#F5A623',
      },
      fontFamily: {
        serif: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        '4xl': '2rem',
        '5xl': '2.5rem',
      },
    },
  },
}
```

## 7. Responsive Breakpoints

| Breakpoint | Width | Layout Changes |
|------------|-------|----------------|
| Mobile | < 640px | Single column, stacked sections, hamburger menu |
| Tablet | 640-1024px | 2-column grids, adjusted spacing |
| Desktop | > 1024px | Full layout, all features visible |

## 8. Performance Considerations

1. **Lazy loading**: Images below fold use loading="lazy"
2. **Video optimization**: Hero video compressed, muted, looped
3. **Font loading**: Google Fonts with display=swap
4. **Animation**: Use transform/opacity only, avoid layout triggers
5. **Code splitting**: Sections can be lazy loaded if needed

## 9. Accessibility

1. Keyboard navigation for all interactive elements
2. ARIA labels on buttons and form fields
3. Focus visible states
4. Color contrast compliance (WCAG AA)
5. Reduced motion media query support
