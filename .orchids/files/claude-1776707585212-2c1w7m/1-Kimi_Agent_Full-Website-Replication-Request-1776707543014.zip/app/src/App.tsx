import { motion } from 'framer-motion';
import { TopHeader } from '@/sections/TopHeader';
import { HeroSection } from '@/sections/HeroSection';
import { BrandsSection } from '@/sections/BrandsSection';
import { WhatWeDo } from '@/sections/WhatWeDo';
import { ServicesSection } from '@/sections/ServicesSection';
import { TeamSection } from '@/sections/TeamSection';
import { CTASection } from '@/sections/CTASection';
import { GallerySection } from '@/sections/GallerySection';
import { ProcessSection } from '@/sections/ProcessSection';
import { TestimonialsSection } from '@/sections/TestimonialsSection';
import { ContactSection } from '@/sections/ContactSection';
import { FooterSection } from '@/sections/FooterSection';

function App() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen bg-white"
    >
      <TopHeader />
      <main>
        <HeroSection />
        <BrandsSection />
        <WhatWeDo />
        <ServicesSection />
        <TeamSection />
        <CTASection />
        <GallerySection />
        <ProcessSection />
        <TestimonialsSection />
        <ContactSection />
      </main>
      <FooterSection />
    </motion.div>
  );
}

export default App;
